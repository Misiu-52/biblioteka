<?php
$conn = mysqli_connect('localhost', 'root','');
mysqli_select_db($conn, "2021_2b1_biblioteka");
?>