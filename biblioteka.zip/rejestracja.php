<?php
	if (isset($_SESSION['zalogowany']))
	{
		header('Location: index.php?plik=ustawienia');
		exit();
	}
?>


<form>
  <label for="login">Login:</label><br>
  <input type="text" id="username" name="xlogin" size="23"><br>
  <label for="pwd">Hasło:</label><br>
  <input type="password" id="pwd" name="xhaslo" size="15"><br>
  <input type="submit" value="Zarejestruj">
</form>
<a href="index.php?plik=logowanie"><button>Logowanie</button></a>